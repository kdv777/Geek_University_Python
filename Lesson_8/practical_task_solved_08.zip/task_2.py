import re

log_string_template = re.compile("""
((?:([\d]{1,3}\.){3}[\d]{1,3})|(?:([a-f0-9]{0,4}:){4,8}[a-f0-9]{0,4}))      # Это IPv4 или IPv6
[\s-]+            # Пробельные и тире
\[(.+)\]          # Дата и время: то, что в квадратных скобках
\s\"
(\w+)             # Запрос: GET, POST или другой
\s
([\/\w]+)         # ресурс
\sHTTP\/[\d\.]+
\"\s
(\d{3})\s         # код ответа
(\d)+             # размер ответа
""", re.VERBOSE)

def log_string_parse(log_string, regex_template):
    rez = regex_template.search(log_string)
    if rez is not None:
        rez = rez.groups()
    else:
        raise ValueError
    return rez[0], rez[3],rez[4],rez[5],rez[6],rez[7]

# Проверка работоспособности функции
#line1 = '54.173.6.142 - - [18/May/2015:20:05:10 +0000] "GET /downloads/product_2 HTTP/1.1" 200 2578 "-" "urlgrabber/3.9.1 yum/3.4.3"'
#line2 = '2001:4802:7802:104:be76:4eff:fe20:82cc - - [18/May/2015:20:05:27 +0000] "GET /downloads/product_1 HTTP/1.1" 200 85619205 "-" "Chef Client/12.0.3 (ruby-2.1.4-p265; ohai-8.0.1; x86_64-linux; +http://opscode.com)"'
# line3 = '2600:3c01::f03c:91ff:fe70:9ee0 - - [25/May/2015:16:05:12 +0000] "GET /downloads/product_2 HTTP/1.1" 206 13864207 "http://www.elasticsearch.org/overview/elkdownloads/" "Mozilla/5.0 (X11; Linux x86_64; rv:34.0) Gecko/20100101 Firefox/34.0"'
# print(log_string_parse(line1, log_string_template))
# print(log_string_parse(line2, log_string_template))
# print(log_string_parse(line3, log_string_template))

ip_all = set()
with open("nginx_logs.log", encoding="UTF-8", mode = "rt") as file:
    for line in file:
        try:
            ip, *_= log_string_parse(line,log_string_template)
            ip_all.add(ip)
        except ValueError:
            print(f"Строка не по шаблону: {line}")

lst_all_ip = list(ip_all)
print(f"Длина списка IP: {len(lst_all_ip)}")
